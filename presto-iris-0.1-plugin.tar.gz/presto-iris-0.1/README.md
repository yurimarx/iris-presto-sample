# Presto InterSystems IRIS Connector

![img_1.png](img_1.png)

[Presto](https://prestodb.io/) is a powerful interactive querying engine that enables running SQL queries on anything -- be it MySQL, HDFS, local file, Kafka -- as long as there exist a connector to the source.

This is Presto connector to the InterSystems IRIS

# Usage

Build from this sources using command 

```shell
./mvnw package
```

Or download the [latest release](https://github.com/caretdev/presto-iris/releases) 



# Local Demo

Start the demo environment using docker-compose

```shell
docker-compose up -d --build
```

For the demo purpose, it uses Apache Superset with [superset-iris](https://github.com/caretdev/superset-iris), 
and examples which comes with it, and it takes a while when it will loaded.

Presto UI will be availble on this link http://localhost:8080/ui/#

When SuperSet will finish load examples after 10-15 minutes, it should became available by link http://localhost:8088/databaseview/list
Using admin/admin as username/password

![img.png](img.png)

